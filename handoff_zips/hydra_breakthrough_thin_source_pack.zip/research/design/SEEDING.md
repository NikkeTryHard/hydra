# Hydra Seeding & Reproducibility

> Seeding strategy and reproducibility guarantees for the Hydra Mahjong AI. Covers RNG hierarchy, per-component seeding, CUDA determinism, and evaluation seed banks.
>
> **Status note:** this is a mixed reference doc. Current authority for what Hydra is today comes from `README.md` -> `research/design/HYDRA_FINAL.md` -> `research/design/HYDRA_RECONCILIATION.md` -> `docs/GAME_ENGINE.md`.
>
> Keep the seeding hierarchy and deterministic replay principles here. Treat older multi-phase RL/opponent-pool specifics as reserve/legacy planning unless the reconciled doctrine explicitly promotes them.

## Related Documents

- [../HYDRA_RECONCILIATION.md](HYDRA_RECONCILIATION.md) — current execution doctrine and active-vs-reserve split
- [../../docs/GAME_ENGINE.md](../../docs/GAME_ENGINE.md) — current runtime reality
- [../HYDRA_ARCHIVE.md](HYDRA_ARCHIVE.md) — archive / reserve-only planning surfaces
- [../infrastructure/INFRASTRUCTURE.md](../infrastructure/INFRASTRUCTURE.md) — implementation/infrastructure reference
- [../infrastructure/CHECKPOINTING.md](../infrastructure/CHECKPOINTING.md) — checkpoint format, save protocol, retention policy

---

## Reproducibility and Seeding Strategy

Training a mahjong AI involves randomness at every layer: tile shuffles, suit augmentation, DataLoader ordering, model initialization, GPU kernel scheduling, and opponent selection. This section specifies how Hydra governs all sources of randomness to enable deterministic replay, meaningful ablations, and post-hoc debugging — without sacrificing training performance.

**Design philosophy:** Seed logging is more valuable than seed fixing. Full bitwise reproducibility is achievable for Phase 1 and useful for debugging, but Phases 2–3 are inherently stochastic due to RL exploration and system-level non-determinism. The strategy therefore prioritizes game-level determinism (always achievable) and component-level isolation (always auditable) over global training determinism (sometimes achievable, never required).

### Master Seed Contract

A single integer master seed governs all randomness in a training run. This seed is the sole input needed to reconstruct the full random state of any component at any point in training.

- **Source:** Passed as a CLI argument (`--seed`). Logged to experiment tracker.
- **Contract:** Same `master_seed` + same code version + same hardware = bitwise-identical Phase 1 training; approximately identical Phases 2–3 (see Known Limitations below).
- **Default behavior:** If no seed is provided, one is generated from system entropy (getrandom), converted to a 64-bit integer, and logged. This ensures every run is reproducible after the fact — the seed is never lost.
- **Rust side:** The master seed feeds into the `rand 0.9+` ecosystem listed in the Crate Dependencies table. All Rust-side RNG is derived from this seed, never from system entropy during training.

### Seed Hierarchy

**Decision: Rust rand crate with ChaCha20Rng as the root of all randomness.**

Seed derivation uses SHA-256 KDF (matching hydra-core's existing seeding infrastructure). This eliminates the classic anti-pattern of using `seed + i` for component seeds, which produces correlated low bits across components.

**Component allocation via `derive_seed()`:**

| Spawn Index | Component | Description |
|-------------|-----------|-------------|
| 0 | Burn model init | Seeds Burn backend RNG before model construction |
| 1 | DataLoader workers | Seeds Burn DataLoader shuffle RNG |
| 2 | Suit augmentation | Seeds per-worker permutation selection |
| 3 | Rust game engine | Session seed for self-play game generation |
| 4 | Reserve opponent-pool selection | Seeds opponent category sampling if a future league/pool phase is revived |
| 5 | Evaluation seed bank | Seeds generation of the fixed evaluation game set |

**Phase-level derivation:** Each major training stage can derive its own seed via `derive_seed(master_seed, stage_number)` using SHA-256 KDF. This keeps replay/debug isolation clean when Hydra adds or revives later stages.

```mermaid
graph TD
    MASTER["master_seed (CLI or getrandom)"]
    MASTER --> P1["derive_seed(master, 1) via SHA-256 KDF"]
    MASTER --> P2["derive_seed(master, 2) via SHA-256 KDF"]
    MASTER --> P3["derive_seed(master, 3) via SHA-256 KDF"]

    P1 --> S0_1["derive(0): Burn Init"]
    P1 --> S1_1["derive(1): DataLoader"]
    P1 --> S2_1["derive(2): Suit Augment"]

    P2 --> S0_2["derive(0): Burn Init"]
    P2 --> S1_2["derive(1): DataLoader"]
    P2 --> S2_2["derive(2): Suit Augment"]
    P2 --> S3_2["derive(3): Rust Self-Play"]

    P3 --> S0_3["derive(0): Burn Init"]
    P3 --> S3_3["derive(3): Rust Self-Play"]
    P3 --> S4_3["derive(4): Opponent Pool"]

    S3_3 --> GAME["Per-Game: set_stream(game_index)"]
    GAME --> KYOKU["Per-Kyoku: SHA-256 KDF --> wall shuffle"]
```

**Anti-patterns (never do):**
- `seed + i` for sequential component seeds — correlated low bits across components
- Reusing the same seed for multiple components — introduces hidden statistical dependencies
- Calling RNG initialization at module load time — pollutes the global RNG state before the hierarchy is established

### Per-Component Seeding

**3a. Burn (model init and training)**

The Burn backend is seeded with `component_seed` before model construction at the start of each phase, ensuring that orthogonal initialization (specified in the [Model Definition](INFRASTRUCTURE.md#model-definition) section) produces identical weights given the same seed. During training, the backend RNG governs any stochastic layers — though Hydra's architecture uses no dropout, so the primary effect is on initialization.

**3b. DataLoader Workers**

Each DataLoader worker receives a deterministic seed derived from the hierarchy's DataLoader child. Workers use this seed to initialize their local ChaCha8Rng, ensuring that the 8 workers specified in the [Data Loading Pipeline](INFRASTRUCTURE.md#gap-2-data-loading-pipeline) section produce deterministic file ordering and buffer shuffling across runs. Workers must never share RNG state or seed from system time.

**3c. Suit Augmentation**

Each DataLoader worker maintains a local ChaCha8Rng for selecting 1-of-6 suit permutations per game, as specified in the [Suit Permutation Augmentation](INFRASTRUCTURE.md#gap-4-suit-permutation-augmentation) section. The local RNG is derived from the worker's own seed (not global state). Over 6 epochs, this produces approximately uniform coverage of all 6 permutations for each game, without requiring coordination between workers.

**3d. Rust Game Engine (Self-Play Seeds)**

The Rust game engine receives a session seed derived from the hierarchy's game engine child. The derivation path:

- **Session level:** `derive_seed(engine_child, 0)` produces a `[u8; 32]` array, used to seed a `ChaCha8Rng` via `from_seed()`.
- **Per-game:** The session `ChaCha8Rng` uses `set_stream(game_index)` to create 2^64 independent game streams from a single session seed. Each game index maps to a unique, non-overlapping keystream.
- **Per-kyoku:** Within each game, wall shuffles use a KDF pattern proven by Mortal: `SHA-256(session_seed || nonce || kyoku || honba)` produces a 32-byte seed for a fresh `ChaCha8Rng` that drives the Fisher-Yates shuffle for that specific kyoku's wall, dead wall, and dora indicators.
- **Version pinning:** Pin `chacha20 = "=0.10.0"` in `Cargo.toml` to ensure cross-version replay stability. A minor version bump in the cipher crate could silently change the keystream, breaking deterministic replay.
- **Shuffle implementation:** Vendor the Fisher-Yates shuffle implementation rather than depending on `rand::seq::SliceRandom`. The `SliceRandom` API has changed distribution behavior across `rand` versions; a vendored shuffle with a fixed algorithm guarantees identical wall orderings across Hydra versions.
- **Cross-reference:** Deterministic replay of `(seed, kyoku, honba) → wall` is the foundation of the evaluation protocol described in the [Rating and Evaluation](INFRASTRUCTURE.md#rating-and-evaluation) section.

**3e. Rayon Thread RNG**

Game seeds are determined before dispatch to rayon workers — rayon distributes work, not randomness. Each game instance receives its pre-computed seed as a value parameter; no per-thread RNG is needed for game simulation. The rayon thread pool is a pure compute resource. If per-thread RNG is ever needed for future extensions (e.g., exploration noise during inference), the pattern is a `thread_local` `ChaCha8Rng` seeded from `game_seed XOR thread_index`, ensuring reproducibility regardless of work-stealing order.

**3f. Reserve Opponent-Pool Selection**

If Hydra later revives a league/pool phase, opponent category selection should use its own derived seed child so matchup schedules are reproducible under the same seed and pool contents. Keep this as reserve planning guidance, not as a claim about the current active tranche.

### GPU Determinism

**Decision: Full determinism available for Phase 1 debugging; relaxed for Phases 2–3 performance.**

| Flag | Phase 1 / supervised stages | Later stochastic stages | Effect |
|------|-------------|-----------------|--------|
| Burn backend seed | Always | Always | Seeds all backend RNG streams |
| cuDNN benchmark off | Always | Always | Disables auto-tuning; fixed-size inputs make determinism simpler, though the live runtime shape is now `192x34` |
| Deterministic kernels | Optional (debug) | No | Forces deterministic CUDA kernels; ~5–15% overhead |

**Implementation notes:**
- bf16 matrix multiplications are deterministic given identical inputs; non-determinism in mixed-precision training comes from reduction ordering in multi-stream operations (e.g., gradient all-reduce), not from the matmul itself.
- GroupNorm (used throughout the model, as specified in the [Model Definition](INFRASTRUCTURE.md#model-definition) section) is fully deterministic — it has no running statistics and no non-deterministic CUDA kernels.
- Conv1d switches to a deterministic cuDNN kernel when deterministic mode is enabled, with ~5–8% overhead compared to the auto-tuned non-deterministic kernel.
- **Recommendation:** Enable full determinism for supervised-stage ablation studies and seed-specific debugging. Later stochastic stages will usually remain non-bitwise-reproducible because exploration and parallel scheduling dominate the variance budget.

### Checkpoint RNG State

Every checkpoint saves the following RNG state alongside model weights and optimizer state:

| Component | What is Saved | Purpose |
|-----------|---------------|---------|
| Burn backend RNG | Backend-specific RNG state via `Record` | Reproducible forward pass on resume |
| System RNG (rand crate) | ChaCha20Rng serialized state | Reproducible Rust-level randomness on resume |
| DataLoader RNG | ChaCha8Rng state per worker | DataLoader and augmentation state |
| Training progress | Epoch number, global step, file cursor position | Reconstruct DataLoader file ordering on resume |

**Resume protocol:** On checkpoint load, all RNG states are restored before the first forward pass. The DataLoader reconstructs its file ordering from the saved epoch number and file cursor, ensuring that resumed training sees exactly the same data sequence as uninterrupted training.

- **Phase 1:** Enables bitwise-identical training continuation — the resumed run produces the same gradients as if it had never been interrupted.
- **Phases 2–3:** Enables approximate resumption. Game trajectories will differ due to thread scheduling non-determinism in rayon, but the statistical properties of the training distribution are preserved.

### Stage Transition Seeding (Reserve / Future Planning)

If Hydra uses multiple training stages with materially different data-generation regimes, re-seed all RNG components from a new stage child at each boundary. This is reserve/future planning guidance, not a claim that every later stage is currently active.

| Component | Phase 1 → 2 | Phase 2 → 3 |
|-----------|-------------|-------------|
| SHA-256 KDF | New child: `derive_seed(master, 2)` | New child: `derive_seed(master, 3)` |
| Burn backend RNG | Re-seeded from new phase child | Re-seeded from new phase child |
| Rust game engine | New session seed | New session seed |
| DataLoader RNG | Re-seeded | Re-seeded |
| Opponent pool RNG | N/A | Initialized from new phase child |

**Rationale:** Re-seeding ensures each phase explores different random trajectories even with the same master seed. Without re-seeding, Phase 2's game engine would replay the same wall shuffles as Phase 1's evaluation games, creating an artificial correlation between training and evaluation data.

### Evaluation Seed Bank (Reference Design)

**Decision: Fixed, published seed bank for all evaluation runs.**

A standardized set of 50,000 game seeds ensures cross-run and cross-version comparability of evaluation results. The seed bank is a first-class artifact, not a runtime computation.

- **Generation:** Derived from a published constant (`EVAL_MASTER = 0x2000`) using `derive_seed(0x2000, i)` for i in 0..50000. The constant follows Mortal's convention for evaluation key derivation.
- **Storage:** Checked into the repository as `data/eval_seeds.json` — never generated at runtime. This eliminates any risk of evaluation seed drift across code versions or platforms.
- **Usage tiers** (matching [INFRASTRUCTURE.md § Rating and Evaluation](INFRASTRUCTURE.md#rating-and-evaluation)):

| Tier | Seeds Used | Games (x4 rotations) | Purpose |
|------|-----------|----------------------|---------|
| Quick eval | First 1,000 | 4,000 | Trend detection during training |
| Full eval | All 50,000 | 200,000 | Publication-quality checkpoint comparison |

- **Cross-reference:** These tiers match the evaluation scale table in the [Rating and Evaluation](INFRASTRUCTURE.md#rating-and-evaluation) section. The ablation tier (250,000 sets / 1M games) uses a separate, larger seed bank generated from `EVAL_MASTER_ABLATION = 0x2001`.
- **Invariant:** The seed bank file is append-only. New seeds may be added for larger evaluations, but existing seeds are never reordered or removed.

### Known Limitations

What cannot be made deterministic and why:

- **Phases 2–3 are NOT bitwise reproducible.** Multiple independent sources of non-determinism interact: GPU reduction ordering in multi-stream operations, rayon work-stealing thread scheduling, and backend-specific kernel non-determinism.
- **Phase 1 CAN be bitwise reproducible** with deterministic CUDA kernels enabled and a fixed seed. This is the recommended configuration for ablation studies and hyperparameter sweeps.
- **Game-level replay IS always deterministic** regardless of training-level non-determinism. Given the same `(seed, kyoku, honba)` tuple, the wall shuffle, dora indicators, and draw order are identical across any platform, any Rust version, any number of threads.
- **Consistent with industry practice:** KataGo, Mortal, and AlphaStar all achieve game-level determinism without full training reproducibility. No production RL system claims bitwise-reproducible multi-phase training.
- **Reporting standard:** Following Henderson et al. 2018, report results over 5+ seeds with confidence intervals. Following Agarwal et al. 2021, use interquartile mean (IQM) with bootstrap confidence intervals for RL evaluation rather than mean +/- standard deviation, which is sensitive to outliers in heavy-tailed reward distributions.

### Seed Logging

Every training run logs the complete seed provenance chain, enabling post-hoc reproduction of any specific game or training state:

- **Run level:** Master seed, phase seed, all component seeds, config file hash, `Cargo.lock` hash.
- **Game level:** Every self-play game logs its game seed in trajectory metadata. This enables replaying any specific game from a training run for debugging or analysis.
- **Evaluation level:** Seed bank file hash and any per-run overrides are logged.
- **Debugging workflow:** Failed reproduction? Check the logged seed, code version, and `Cargo.lock` hash. If all three match, the discrepancy is due to system-level non-determinism (thread scheduling, GPU reduction order) — not a code bug.
