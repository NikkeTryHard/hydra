//! Robust opponent modeling: KL-ball uncertainty + archetype soft-min.

pub fn log_sum_exp_f32(values: &[f32]) -> f32 {
    if values.is_empty() {
        return f32::NEG_INFINITY;
    }
    let max_v = values.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
    if max_v == f32::NEG_INFINITY {
        return f32::NEG_INFINITY;
    }
    let sum: f32 = values.iter().map(|v| (v - max_v).exp()).sum();
    max_v + sum.ln()
}

pub struct ArchetypeWeights {
    pub weights: Vec<f32>,
}

impl ArchetypeWeights {
    pub fn uniform(n: usize) -> Self {
        Self {
            weights: vec![1.0 / n as f32; n],
        }
    }

    pub fn num_archetypes(&self) -> usize {
        self.weights.len()
    }

    pub fn reset(&mut self) {
        let n = self.weights.len();
        let w = 1.0 / n as f32;
        for v in &mut self.weights {
            *v = w;
        }
    }

    pub fn is_confident(&self, threshold: f32) -> bool {
        self.weights.iter().any(|&w| w >= threshold)
    }

    pub fn most_likely(&self) -> usize {
        self.weights
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal))
            .map(|(i, _)| i)
            .unwrap_or(0)
    }

    pub fn entropy(&self) -> f32 {
        let mut h = 0.0f32;
        for &w in &self.weights {
            if w > 1e-8 {
                h -= w * w.ln();
            }
        }
        h
    }

    pub fn update_posterior(&mut self, log_likelihoods: &[f32]) {
        let max_ll = log_likelihoods
            .iter()
            .cloned()
            .fold(f32::NEG_INFINITY, f32::max);
        for (w, &ll) in self.weights.iter_mut().zip(log_likelihoods) {
            *w *= (ll - max_ll).exp();
        }
        let sum: f32 = self.weights.iter().sum();
        if sum > 0.0 {
            for w in &mut self.weights {
                *w /= sum;
            }
        }
    }
}

pub struct RobustOpponentConfig {
    pub epsilon: f32,
    pub tau_search_iters: u8,
    pub num_archetypes: usize,
    pub tau_arch: f32,
}

impl RobustOpponentConfig {
    pub fn with_epsilon(mut self, epsilon: f32) -> Self {
        self.epsilon = epsilon;
        self
    }
}

impl RobustOpponentConfig {
    pub fn new(epsilon: f32, num_archetypes: usize) -> Self {
        Self {
            epsilon,
            num_archetypes,
            ..Default::default()
        }
    }
}

impl RobustOpponentConfig {
    pub fn summary(&self) -> String {
        format!(
            "robust(eps={:.2}, arch={}, tau={:.1})",
            self.epsilon, self.num_archetypes, self.tau_arch
        )
    }

    pub fn validate(&self) -> Result<(), &'static str> {
        if self.epsilon <= 0.0 {
            return Err("epsilon must be positive");
        }
        if self.num_archetypes == 0 {
            return Err("need at least 1 archetype");
        }
        Ok(())
    }
}

impl RobustOpponentConfig {
    pub fn with_tau_iters(mut self, iters: u8) -> Self {
        self.tau_search_iters = iters;
        self
    }

    pub fn with_tau_arch(mut self, tau: f32) -> Self {
        self.tau_arch = tau;
        self
    }

    pub fn with_archetypes(mut self, n: usize) -> Self {
        self.num_archetypes = n;
        self
    }
}

impl Default for RobustOpponentConfig {
    fn default() -> Self {
        Self {
            epsilon: 0.2,
            tau_search_iters: 20,
            num_archetypes: 4,
            tau_arch: 1.0,
        }
    }
}

pub fn calibrate_epsilon(observed_kl_samples: &[f32], quantile: f32) -> f32 {
    if observed_kl_samples.is_empty() {
        return 0.2;
    }
    let mut sorted = observed_kl_samples.to_vec();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
    let idx = ((quantile * sorted.len() as f32) as usize).min(sorted.len() - 1);
    sorted[idx]
}

pub fn kl_divergence(q: &[f32], p: &[f32]) -> f32 {
    assert_eq!(q.len(), p.len());
    let mut kl = 0.0f32;
    for (&qi, &pi) in q.iter().zip(p.iter()) {
        if qi > 1e-10 && pi > 1e-10 {
            kl += qi * (qi / pi).ln();
        }
    }
    kl
}

pub fn find_robust_tau(p: &[f32], q_values: &[f32], epsilon: f32, iters: u8) -> (f32, Vec<f32>) {
    assert_eq!(p.len(), q_values.len());
    let n = p.len();
    let mut tau_lo = 0.01f32;
    let mut tau_hi = 100.0f32;
    let mut best_tau = 1.0f32;
    let mut best_q = vec![0.0f32; n];

    for _ in 0..iters {
        let tau = (tau_lo + tau_hi) / 2.0;
        let mut q_tau = vec![0.0f32; n];
        let mut max_val = f32::NEG_INFINITY;
        for i in 0..n {
            let v = p[i].max(1e-8).ln() - q_values[i] / tau;
            if v > max_val {
                max_val = v;
            }
        }
        let mut z = 0.0f32;
        for i in 0..n {
            q_tau[i] = (p[i].max(1e-8).ln() - q_values[i] / tau - max_val).exp();
            z += q_tau[i];
        }
        for v in &mut q_tau {
            *v /= z;
        }

        let mut kl = 0.0f32;
        for i in 0..n {
            if q_tau[i] > 1e-10 && p[i] > 1e-10 {
                kl += q_tau[i] * (q_tau[i] / p[i]).ln();
            }
        }

        if kl > epsilon {
            tau_lo = tau;
        } else {
            tau_hi = tau;
        }
        best_tau = tau;
        best_q = q_tau;
    }
    (best_tau, best_q)
}

pub fn robust_policy(p: &[f32], q_values: &[f32], epsilon: f32, iters: u8) -> Vec<f32> {
    let (_, q_tau) = find_robust_tau(p, q_values, epsilon, iters);
    q_tau
}

pub fn expected_q_value(policy: &[f32], q_values: &[f32]) -> f32 {
    assert_eq!(policy.len(), q_values.len());
    policy
        .iter()
        .zip(q_values.iter())
        .map(|(&w, &q)| w * q)
        .sum()
}

pub fn robust_backup(p: &[f32], q_values: &[f32], epsilon: f32, iters: u8) -> (f32, f32, Vec<f32>) {
    let (tau, q_tau) = find_robust_tau(p, q_values, epsilon, iters);
    let value = expected_q_value(&q_tau, q_values);
    (tau, value, q_tau)
}

pub fn archetype_softmin(q_per_arch: &[Vec<f32>], weights: &[f32], tau_arch: f32) -> Vec<f32> {
    if q_per_arch.is_empty() {
        return Vec::new();
    }
    let n_actions = q_per_arch[0].len();
    let mut result = vec![0.0f32; n_actions];
    for a in 0..n_actions {
        let mut max_v = f32::NEG_INFINITY;
        for (i, qs) in q_per_arch.iter().enumerate() {
            let v = weights[i].max(1e-8).ln() - qs[a] / tau_arch;
            if v > max_v {
                max_v = v;
            }
        }
        let mut sum = 0.0f32;
        for (i, qs) in q_per_arch.iter().enumerate() {
            sum += (weights[i].max(1e-8).ln() - qs[a] / tau_arch - max_v).exp();
        }
        result[a] = -tau_arch * (max_v + sum.max(1e-8).ln());
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn robust_tau_converges() {
        let p = vec![0.3, 0.5, 0.2];
        let q = vec![1.0, 0.5, 2.0];
        let eps = 0.1;
        let (tau, q_tau) = find_robust_tau(&p, &q, eps, 20);
        assert!(tau > 0.0);
        let sum: f32 = q_tau.iter().sum();
        assert!((sum - 1.0).abs() < 0.01, "q_tau should sum to 1");
        let mut kl = 0.0f32;
        for i in 0..3 {
            if q_tau[i] > 1e-10 && p[i] > 1e-10 {
                kl += q_tau[i] * (q_tau[i] / p[i]).ln();
            }
        }
        let kl_error = (kl - eps).abs() / eps;
        assert!(kl_error < 0.05, "KL={kl} should be within 5% of eps={eps}");
    }

    #[test]
    fn archetype_softmin_equal_q() {
        let qs = vec![vec![1.0, 2.0, 3.0]; 4];
        let w = vec![0.25; 4];
        let result = archetype_softmin(&qs, &w, 1.0);
        assert_eq!(result.len(), 3);
        for (i, &val) in result.iter().enumerate().take(3) {
            let expected = i as f32 + 1.0;
            assert!(
                (val - expected).abs() < 0.1,
                "expected ~{expected}, got {val}",
            );
        }
    }

    #[test]
    fn archetype_softmin_different_q_shifts() {
        let qs = vec![
            vec![1.0, 5.0, 3.0],
            vec![5.0, 1.0, 3.0],
            vec![3.0, 3.0, 1.0],
            vec![3.0, 3.0, 5.0],
        ];
        let w = vec![0.25; 4];
        let result = archetype_softmin(&qs, &w, 1.0);
        assert_eq!(result.len(), 3);
        for v in &result {
            assert!(v.is_finite());
        }
    }

    #[test]
    fn robust_tau_uniform_policy() {
        let p = vec![0.25, 0.25, 0.25, 0.25];
        let q = vec![1.0, 2.0, 3.0, 4.0];
        let (tau, q_tau) = find_robust_tau(&p, &q, 0.05, 20);
        assert!(tau > 0.0);
        let sum: f32 = q_tau.iter().sum();
        assert!((sum - 1.0).abs() < 0.01);
    }

    #[test]
    fn robust_tau_zero_prior_no_nan() {
        let p = vec![0.0, 0.5, 0.0, 0.5];
        let q = vec![1.0, 2.0, 3.0, 4.0];
        let (tau, q_tau) = find_robust_tau(&p, &q, 0.1, 20);
        assert!(
            tau.is_finite(),
            "tau should be finite with zero priors: {tau}"
        );
        for (i, &v) in q_tau.iter().enumerate() {
            assert!(v.is_finite(), "q_tau[{i}] should be finite, got {v}");
        }
        let sum: f32 = q_tau.iter().sum();
        assert!((sum - 1.0).abs() < 0.01, "q_tau should sum to 1, got {sum}");
    }

    #[test]
    fn robust_tau_identical_q_stays_close_to_prior() {
        let p = vec![0.3, 0.5, 0.2];
        let q = vec![1.0, 1.0, 1.0];
        let (_, q_tau) = find_robust_tau(&p, &q, 0.1, 20);
        let sum: f32 = q_tau.iter().sum();
        assert!((sum - 1.0).abs() < 0.01);
        for i in 0..3 {
            assert!(
                (q_tau[i] - p[i]).abs() < 0.2,
                "identical Q -> q_tau should be near prior: {} vs {}",
                q_tau[i],
                p[i]
            );
        }
    }

    #[test]
    fn kl_divergence_zero_for_equal_distributions() {
        let p = [0.2, 0.3, 0.5];
        assert!(kl_divergence(&p, &p) < 1e-8);
    }

    #[test]
    fn robust_backup_is_not_above_prior_expectation() {
        let p = vec![0.2, 0.5, 0.3];
        let q = vec![3.0, 1.0, 2.0];
        let prior_value = expected_q_value(&p, &q);
        let (_, robust_value, q_tau) = robust_backup(&p, &q, 0.1, 24);
        assert!(robust_value <= prior_value + 1e-4);
        assert!((q_tau.iter().sum::<f32>() - 1.0).abs() < 0.01);
        assert!(kl_divergence(&q_tau, &p) <= 0.11);
    }

    #[test]
    fn robust_policy_matches_backup_policy() {
        let p = vec![0.25, 0.25, 0.25, 0.25];
        let q = vec![4.0, 1.0, 3.0, 2.0];
        let policy = robust_policy(&p, &q, 0.05, 20);
        let (_, _, backup_policy) = robust_backup(&p, &q, 0.05, 20);
        assert_eq!(policy.len(), backup_policy.len());
        for i in 0..policy.len() {
            assert!((policy[i] - backup_policy[i]).abs() < 1e-6);
        }
    }
}
