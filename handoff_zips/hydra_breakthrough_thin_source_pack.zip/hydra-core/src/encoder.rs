//! Fixed-superset observation tensor encoder for neural network input.
//!
//! Encodes the full game state into a flat `[f32; NUM_CHANNELS * 34]` array
//! (row-major) that serves as input to the Hydra SE-ResNet model.
//!
//! The currently implemented baseline channels remain intact in the first 85
//! planes. Additional Group C / Group D planes provide a fixed-shape superset
//! for search/belief and Hand-EV context, with zero-filled planes plus
//! presence-mask channels when those dynamic features are unavailable.
//!
//! Channels are grouped:
//!
//! - 0..3:   closed hand (thresholded tile counts)
//! - 4..7:   open meld hand counts (thresholded)
//! - 8:      drawn tile one-hot
//! - 9..10:  shanten masks (keep / next)
//! - 11..22: discards per player (presence, tedashi, temporal)
//! - 23..34: melds per player (chi, pon, kan)
//! - 35..39: dora indicator thermometer
//! - 40..42: aka dora flags (per suit plane)
//! - 43..61: game metadata (riichi, scores, gaps, shanten, round, honba, kyotaku)
//! - 62..84: safety channels (genbutsu, suji, kabe, one-chance, tenpai)
//! - 85..149: Group C search/belief context + presence masks + reserved slots
//! - 150..191: Group D Hand-EV context + presence mask
use crate::hand_ev::HandEvFeatures;
use crate::safety::SafetyInfo;
use crate::tile::NUM_TILE_TYPES;

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/// Baseline observation channels (public + safety).
pub const BASELINE_CHANNELS: usize = 85;

/// Group C search/belief context channels.
pub const SEARCH_CONTEXT_CHANNELS: usize = 65;

/// Group D Hand-EV channels.
pub const HAND_EV_CHANNELS: usize = 42;

/// First Group C search/belief channel.
pub const SEARCH_CHANNEL_START: usize = BASELINE_CHANNELS;

/// First Group C belief-field channel.
pub const SEARCH_BELIEF_CHANNEL_START: usize = SEARCH_CHANNEL_START;

/// First Group D Hand-EV channel.
pub const HAND_EV_CHANNEL_START: usize = SEARCH_CHANNEL_START + SEARCH_CONTEXT_CHANNELS;

/// Group C discard-level delta-Q channel.
pub const SEARCH_DELTA_Q_CHANNEL: usize = SEARCH_CHANNEL_START + 22;

/// Group C mixture-entropy scalar channel.
pub const SEARCH_MIXTURE_ENTROPY_CHANNEL: usize = SEARCH_CHANNEL_START + 20;

/// Group C mixture-ESS scalar channel.
pub const SEARCH_MIXTURE_ESS_CHANNEL: usize = SEARCH_CHANNEL_START + 21;

/// First Group C opponent-risk channel.
pub const SEARCH_RISK_CHANNEL_START: usize = SEARCH_CHANNEL_START + 23;

/// First Group C opponent-stress channel.
pub const SEARCH_STRESS_CHANNEL_START: usize = SEARCH_CHANNEL_START + 26;

/// First Group C presence-mask channel.
pub const SEARCH_MASK_CHANNEL_START: usize = SEARCH_CHANNEL_START + 29;

/// Final Group D Hand-EV presence-mask channel.
pub const HAND_EV_MASK_CHANNEL: usize = HAND_EV_CHANNEL_START + HAND_EV_CHANNELS - 1;

/// Total observation channels.
pub const NUM_CHANNELS: usize = BASELINE_CHANNELS + SEARCH_CONTEXT_CHANNELS + HAND_EV_CHANNELS;

/// Tiles per channel (one per tile type).
pub const NUM_TILES: usize = NUM_TILE_TYPES; // 34

/// Total elements in the flat observation buffer.
pub const OBS_SIZE: usize = NUM_CHANNELS * NUM_TILES;

// -- Channel group starts --

const CH_HAND: usize = 0; // 0..3   (4 channels)
const CH_OPEN_MELD: usize = 4; // 4..7   (4 channels)
const CH_DRAWN: usize = 8; // 8      (1 channel)
const CH_SHANTEN_MASK: usize = 9; // 9..10  (2 channels)
const CH_DISCARDS: usize = 11; // 11..22 (12 channels: 3 per player)
const CH_MELDS: usize = 23; // 23..34 (12 channels: 3 per player)
const CH_DORA: usize = 35; // 35..39 (5 channels)
const CH_AKA: usize = 40; // 40..42 (3 channels)
const CH_META: usize = 43; // 43..61 (19 channels)
const CH_SAFETY: usize = 62; // 62..84 (23 channels)
const CH_SEARCH: usize = SEARCH_CHANNEL_START; // 85..149 (65 channels)
const CH_HAND_EV: usize = HAND_EV_CHANNEL_START; // 150..191 (42 channels)

const SEARCH_BELIEF_CHANNELS: usize = 16;
const SEARCH_MIXTURE_WEIGHT_CHANNELS: usize = 4;
const SEARCH_RISK_CHANNELS: usize = 3;
const SEARCH_STRESS_CHANNELS: usize = 3;
const SEARCH_MASK_CHANNELS: usize = 4;
const SEARCH_RESERVED_CHANNELS: usize = 32;

const CH_SEARCH_BELIEF: usize = CH_SEARCH; // 85..100
const CH_SEARCH_MIXTURE_WEIGHT: usize = CH_SEARCH_BELIEF + SEARCH_BELIEF_CHANNELS; // 101..104
const CH_SEARCH_MIXTURE_ENTROPY: usize = CH_SEARCH_MIXTURE_WEIGHT + SEARCH_MIXTURE_WEIGHT_CHANNELS; // 105
const CH_SEARCH_MIXTURE_ESS: usize = CH_SEARCH_MIXTURE_ENTROPY + 1; // 106
const CH_SEARCH_DELTA_Q: usize = CH_SEARCH_MIXTURE_ESS + 1; // 107
const CH_SEARCH_RISK: usize = CH_SEARCH_DELTA_Q + 1; // 108..110
const CH_SEARCH_STRESS: usize = CH_SEARCH_RISK + SEARCH_RISK_CHANNELS; // 111..113
const CH_SEARCH_MASKS: usize = CH_SEARCH_STRESS + SEARCH_STRESS_CHANNELS; // 114..117
const CH_SEARCH_RESERVED: usize = CH_SEARCH_MASKS + SEARCH_MASK_CHANNELS; // 118..149

const CH_HAND_EV_TENPAI: usize = CH_HAND_EV; // 150..152
const CH_HAND_EV_WIN: usize = CH_HAND_EV_TENPAI + 3; // 153..155
const CH_HAND_EV_SCORE: usize = CH_HAND_EV_WIN + 3; // 156
const CH_HAND_EV_UKEIRE: usize = CH_HAND_EV_SCORE + 1; // 157..190
const CH_HAND_EV_MASK: usize = CH_HAND_EV_UKEIRE + NUM_TILES; // 191

/// Number of players at the table.
const NUM_PLAYERS: usize = 4;

/// Fixed-shape Group C search/belief context planes.
#[derive(Debug, Clone)]
pub struct SearchFeaturePlanes {
    pub belief_fields: [[f32; NUM_TILES]; SEARCH_BELIEF_CHANNELS],
    pub mixture_weights: [f32; SEARCH_MIXTURE_WEIGHT_CHANNELS],
    pub mixture_entropy: f32,
    pub mixture_ess: f32,
    pub delta_q: [f32; NUM_TILES],
    pub opponent_risk: [[f32; NUM_TILES]; SEARCH_RISK_CHANNELS],
    pub opponent_stress: [f32; SEARCH_STRESS_CHANNELS],
    pub belief_features_present: bool,
    pub search_features_present: bool,
    pub robust_features_present: bool,
    pub context_features_present: bool,
}

impl Default for SearchFeaturePlanes {
    fn default() -> Self {
        Self {
            belief_fields: [[0.0; NUM_TILES]; SEARCH_BELIEF_CHANNELS],
            mixture_weights: [0.0; SEARCH_MIXTURE_WEIGHT_CHANNELS],
            mixture_entropy: 0.0,
            mixture_ess: 0.0,
            delta_q: [0.0; NUM_TILES],
            opponent_risk: [[0.0; NUM_TILES]; SEARCH_RISK_CHANNELS],
            opponent_stress: [0.0; SEARCH_STRESS_CHANNELS],
            belief_features_present: false,
            search_features_present: false,
            robust_features_present: false,
            context_features_present: false,
        }
    }
}

// ---------------------------------------------------------------------------
// ObservationEncoder
// ---------------------------------------------------------------------------

/// Pre-allocated encoder buffer for the fixed-superset observation tensor.
///
/// Reuse across turns to avoid per-turn allocation. Call [`clear`] then
/// the individual `encode_*` methods, or use [`encode`] as the one-shot
/// entry point.
#[derive(Clone)]
#[repr(C)]
pub struct ObservationEncoder {
    /// Flat buffer: `NUM_CHANNELS` channels x 34 tiles, row-major.
    buffer: [f32; OBS_SIZE],
}

impl ObservationEncoder {
    /// Create a new encoder with a zeroed buffer.
    #[inline]
    pub fn new() -> Self {
        Self {
            buffer: [0.0; OBS_SIZE],
        }
    }

    /// Zero the entire buffer.
    #[inline]
    pub fn clear(&mut self) {
        self.buffer.fill(0.0);
    }

    /// Zero only the channels in range `[start_ch, end_ch)` (exclusive end).
    #[inline]
    pub fn clear_range(&mut self, start_ch: usize, end_ch: usize) {
        let start = start_ch * NUM_TILES;
        let end = end_ch * NUM_TILES;
        self.buffer[start..end].fill(0.0);
    }

    /// Read-only view of the flat observation buffer.
    #[inline]
    pub fn as_slice(&self) -> &[f32; OBS_SIZE] {
        &self.buffer
    }

    /// Set a single cell: `buffer[channel * 34 + tile] = value`.
    #[inline]
    fn set(&mut self, channel: usize, tile: usize, value: f32) {
        self.buffer[channel * NUM_TILES + tile] = value;
    }

    /// Fill an entire channel with a uniform value.
    #[inline]
    fn fill_channel(&mut self, channel: usize, value: f32) {
        let start = channel * NUM_TILES;
        self.buffer[start..start + NUM_TILES].fill(value);
    }

    #[inline]
    fn copy_channel(&mut self, channel: usize, values: &[f32; NUM_TILES]) {
        let start = channel * NUM_TILES;
        self.buffer[start..start + NUM_TILES].copy_from_slice(values);
    }
}

impl Default for ObservationEncoder {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// Encoding: closed hand (channels 0-3)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode the observer's closed hand tile counts into channels 0-3.
    ///
    /// Binary thresholded planes:
    /// - Ch 0: count >= 1
    /// - Ch 1: count >= 2
    /// - Ch 2: count >= 3
    /// - Ch 3: count == 4
    #[inline]
    pub fn encode_hand(&mut self, hand_counts: &[u8; NUM_TILES]) {
        for (tile, &count) in hand_counts.iter().enumerate() {
            let vals = &THERMO[count as usize];
            self.buffer[CH_HAND * NUM_TILES + tile] = vals[0];
            self.buffer[(CH_HAND + 1) * NUM_TILES + tile] = vals[1];
            self.buffer[(CH_HAND + 2) * NUM_TILES + tile] = vals[2];
            self.buffer[(CH_HAND + 3) * NUM_TILES + tile] = vals[3];
        }
    }
}

// ---------------------------------------------------------------------------
// Encoding: open meld hand counts (channels 4-7)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode tile counts contributed by open melds into channels 4-7.
    ///
    /// Same thermometer encoding as the closed hand:
    /// - Ch 4: count >= 1
    /// - Ch 5: count >= 2
    /// - Ch 6: count >= 3
    /// - Ch 7: count == 4
    #[inline]
    pub fn encode_open_meld_hand(&mut self, counts: &[u8; NUM_TILES]) {
        for (tile, &count) in counts.iter().enumerate() {
            let vals = &THERMO[count as usize];
            self.buffer[CH_OPEN_MELD * NUM_TILES + tile] = vals[0];
            self.buffer[(CH_OPEN_MELD + 1) * NUM_TILES + tile] = vals[1];
            self.buffer[(CH_OPEN_MELD + 2) * NUM_TILES + tile] = vals[2];
            self.buffer[(CH_OPEN_MELD + 3) * NUM_TILES + tile] = vals[3];
        }
    }
}

// ---------------------------------------------------------------------------
// Encoding: drawn tile (channel 8)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode the drawn tile as a one-hot on channel 8.
    /// `None` means no tile was drawn (e.g. first turn or after a call).
    #[inline]
    pub fn encode_drawn_tile(&mut self, tile: Option<u8>) {
        if let Some(t) = tile {
            let idx = t as usize;
            if idx < NUM_TILES {
                self.set(CH_DRAWN, idx, 1.0);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Encoding: shanten masks (channels 9-10)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode shanten-based discard masks into channels 9-10.
    ///
    /// - Ch 9 (keep-shanten): 1.0 for tiles whose discard does not increase shanten.
    /// - Ch 10 (next-shanten): 1.0 for tiles whose discard decreases shanten.
    ///
    /// `hand` is the full hand including drawn tile (typically 14 tiles).
    #[inline]
    pub fn encode_shanten_masks(&mut self, hand: &[u8; NUM_TILES]) {
        let total: u8 = hand.iter().sum();
        let len_div3 = total / 3;
        let batch = crate::shanten_batch::batch_discard_shanten(hand, len_div3);
        for tile in 0..NUM_TILES {
            if let Some(after) = batch.discard[tile] {
                if after <= batch.base {
                    self.set(CH_SHANTEN_MASK, tile, 1.0);
                }
                if after < batch.base {
                    self.set(CH_SHANTEN_MASK + 1, tile, 1.0);
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Discard info input type
// ---------------------------------------------------------------------------

/// A single discard event for encoding.
#[derive(Debug, Clone, Copy)]
pub struct DiscardEntry {
    /// Tile type (0-33).
    pub tile: u8,
    /// True if discarded from hand (not tsumogiri).
    pub is_tedashi: bool,
    /// 0-based turn index when this discard happened.
    pub turn: u16,
}

/// Per-player discard history for encoding.
#[derive(Debug, Clone, Copy)]
pub struct PlayerDiscards {
    /// Fixed-size array of discards (oldest first).
    pub discards: [DiscardEntry; 30],
    /// Number of valid entries in `discards`.
    pub len: u8,
}

impl Default for PlayerDiscards {
    fn default() -> Self {
        Self::new()
    }
}

impl PlayerDiscards {
    /// Create an empty discard history.
    #[inline]
    pub fn new() -> Self {
        Self {
            discards: [DiscardEntry {
                tile: 0,
                is_tedashi: false,
                turn: 0,
            }; 30],
            len: 0,
        }
    }

    /// Append a discard entry. Silently drops if at capacity (30).
    #[inline]
    pub fn push(&mut self, entry: DiscardEntry) {
        let i = self.len as usize;
        if i < 30 {
            self.discards[i] = entry;
            self.len += 1;
        }
    }

    /// Return a slice of valid entries.
    #[inline]
    pub fn as_slice(&self) -> &[DiscardEntry] {
        &self.discards[..self.len as usize]
    }
}

// ---------------------------------------------------------------------------
// Encoding: discards (channels 11-22)
// ---------------------------------------------------------------------------

/// Precomputed `exp(-DISCARD_DECAY * i)` for `i` in `0..=30`.
/// DISCARD_DECAY is 0.2, so entry `i` = `exp(-0.2 * i)`.
#[allow(clippy::excessive_precision)]
const DISCARD_EXP_TABLE: [f32; 31] = [
    1.0,           // exp(0.0)
    0.818_730_8,   // exp(-0.2)
    0.670_320_0,   // exp(-0.4)
    0.548_811_6,   // exp(-0.6)
    0.449_329_0,   // exp(-0.8)
    0.367_879_5,   // exp(-1.0)
    0.301_194_2,   // exp(-1.2)
    0.246_597_0,   // exp(-1.4)
    0.201_896_5,   // exp(-1.6)
    0.165_298_9,   // exp(-1.8)
    0.135_335_3,   // exp(-2.0)
    0.110_803_2,   // exp(-2.2)
    0.090_717_96,  // exp(-2.4)
    0.074_273_58,  // exp(-2.6)
    0.060_810_06,  // exp(-2.8)
    0.049_787_07,  // exp(-3.0)
    0.040_762_20,  // exp(-3.2)
    0.033_373_27,  // exp(-3.4)
    0.027_323_72,  // exp(-3.6)
    0.022_370_77,  // exp(-3.8)
    0.018_315_64,  // exp(-4.0)
    0.014_995_58,  // exp(-4.2)
    0.012_277_34,  // exp(-4.4)
    0.010_051_84,  // exp(-4.6)
    0.008_229_747, // exp(-4.8)
    0.006_737_947, // exp(-5.0)
    0.005_516_564, // exp(-5.2)
    0.004_516_581, // exp(-5.4)
    0.003_697_864, // exp(-5.6)
    0.003_027_555, // exp(-5.8)
    0.002_478_752, // exp(-6.0)
];
// Thermometer encoding table for 0..4 counts (per tile, 4 channels)
const THERMO: [[f32; 4]; 5] = [
    [0.0, 0.0, 0.0, 0.0],
    [1.0, 0.0, 0.0, 0.0],
    [1.0, 1.0, 0.0, 0.0],
    [1.0, 1.0, 1.0, 0.0],
    [1.0, 1.0, 1.0, 1.0],
];

impl ObservationEncoder {
    /// Encode discard info for all 4 players into channels 11-22.
    ///
    /// Per player (3 channels each):
    /// - presence:  binary 1.0 if tile was discarded by this player
    /// - tedashi:   binary 1.0 if that discard was from hand (not tsumogiri)
    /// - temporal:  exp(-0.2 * (t_max - t_discard))
    #[inline]
    pub fn encode_discards(&mut self, discards: &[PlayerDiscards; NUM_PLAYERS]) {
        for (p, pd) in discards.iter().enumerate() {
            let ch_base = CH_DISCARDS + 3 * p;
            let sl = pd.as_slice();
            let t_max = sl.iter().map(|d| d.turn).max().unwrap_or(0);
            for d in sl {
                let t = d.tile as usize;
                if t >= NUM_TILES {
                    continue;
                }
                self.set(ch_base, t, 1.0);
                if d.is_tedashi {
                    self.set(ch_base + 1, t, 1.0);
                }
                let dt = (t_max - d.turn).min(30) as usize;
                let w = DISCARD_EXP_TABLE[dt];
                let idx = (ch_base + 2) * NUM_TILES + t;
                if w > self.buffer[idx] {
                    self.buffer[idx] = w;
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Meld info input type
// ---------------------------------------------------------------------------

/// Type of meld for encoding purposes.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MeldType {
    /// Chi (sequence call).
    Chi,
    /// Pon (triplet call).
    Pon,
    /// Kan (any kan: ankan, daiminkan, kakan).
    Kan,
}

/// A single meld for encoding.
#[derive(Debug, Clone, Copy)]
pub struct MeldInfo {
    /// Tile types present in the meld (0-33 each). Up to 4 tiles.
    pub tiles: [u8; 4],
    /// Number of valid tiles in `tiles`.
    pub tile_count: u8,
    /// What kind of meld this is.
    pub meld_type: MeldType,
}

/// Per-player meld collection for encoding.
#[derive(Debug, Clone, Copy)]
pub struct PlayerMelds {
    /// Fixed-size array of melds (max 4 per player).
    pub melds: [MeldInfo; 4],
    /// Number of valid melds.
    pub len: u8,
}

impl Default for PlayerMelds {
    fn default() -> Self {
        Self::new()
    }
}

impl PlayerMelds {
    /// Create an empty meld collection.
    #[inline]
    pub fn new() -> Self {
        Self {
            melds: [MeldInfo {
                tiles: [0; 4],
                tile_count: 0,
                meld_type: MeldType::Chi,
            }; 4],
            len: 0,
        }
    }

    /// Append a meld. Silently drops if at capacity (4).
    #[inline]
    pub fn push(&mut self, meld: MeldInfo) {
        let i = self.len as usize;
        if i < 4 {
            self.melds[i] = meld;
            self.len += 1;
        }
    }

    /// Return a slice of valid melds.
    #[inline]
    pub fn as_slice(&self) -> &[MeldInfo] {
        &self.melds[..self.len as usize]
    }
}

// ---------------------------------------------------------------------------
// Encoding: melds (channels 23-34)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode melds for all 4 players into channels 23-34.
    ///
    /// Per player (3 channels each):
    /// - chi tiles
    /// - pon tiles
    /// - kan tiles
    #[inline]
    pub fn encode_melds(&mut self, melds: &[PlayerMelds; NUM_PLAYERS]) {
        for (p, player_melds) in melds.iter().enumerate() {
            let ch_base = CH_MELDS + 3 * p;
            for meld in player_melds.as_slice() {
                let ch_offset = match meld.meld_type {
                    MeldType::Chi => 0,
                    MeldType::Pon => 1,
                    MeldType::Kan => 2,
                };
                for &tile in &meld.tiles[..meld.tile_count as usize] {
                    let t = tile as usize;
                    if t < NUM_TILES {
                        self.set(ch_base + ch_offset, t, 1.0);
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Encoding: dora (channels 35-39) and aka (channels 40-42)
// ---------------------------------------------------------------------------

/// Dora information for encoding.
#[derive(Debug, Clone, Copy)]
pub struct DoraInfo {
    /// Dora indicator tile types (0-33). Fixed array, up to 5 kan dora.
    pub indicators: [u8; 5],
    /// Number of valid indicators.
    pub indicator_count: u8,
    /// Aka dora flags: `[has_aka_5m, has_aka_5p, has_aka_5s]`.
    pub aka_flags: [bool; 3],
}

impl ObservationEncoder {
    /// Encode dora indicators as a thermometer into channels 35-39.
    ///
    /// Counts how many indicators point to each tile type, then thresholds:
    /// - Ch 35: count >= 1
    /// - Ch 36: count >= 2
    /// - Ch 37: count >= 3
    /// - Ch 38: count >= 4
    /// - Ch 39: count >= 5
    #[inline]
    pub fn encode_dora(&mut self, dora: &DoraInfo) {
        let mut counts = [0u8; NUM_TILES];
        for &ind in &dora.indicators[..dora.indicator_count as usize] {
            let i = ind as usize;
            if i < NUM_TILES {
                counts[i] = counts[i].saturating_add(1);
            }
        }
        for (tile, &c) in counts.iter().enumerate() {
            if c >= 1 {
                self.set(CH_DORA, tile, 1.0);
            }
            if c >= 2 {
                self.set(CH_DORA + 1, tile, 1.0);
            }
            if c >= 3 {
                self.set(CH_DORA + 2, tile, 1.0);
            }
            if c >= 4 {
                self.set(CH_DORA + 3, tile, 1.0);
            }
            if c >= 5 {
                self.set(CH_DORA + 4, tile, 1.0);
            }
        }
    }

    /// Encode aka dora flags into channels 40-42 (one plane per suit).
    ///
    /// Each channel is fully filled with 1.0 if the corresponding aka is present.
    /// - Ch 40: has red 5m
    /// - Ch 41: has red 5p
    /// - Ch 42: has red 5s
    #[inline]
    pub fn encode_aka(&mut self, dora: &DoraInfo) {
        for (suit, &has_aka) in dora.aka_flags.iter().enumerate() {
            if has_aka {
                self.fill_channel(CH_AKA + suit, 1.0);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Game metadata input type
// ---------------------------------------------------------------------------

/// Game metadata for encoding channels 43-61.
#[derive(Debug, Clone)]
#[repr(C)]
pub struct GameMetadata {
    /// Riichi status for all 4 players (relative to observer). Index 0 = self.
    pub riichi: [bool; 4],
    /// Scores for all 4 players (relative to observer). Raw point values.
    pub scores: [i32; 4],
    /// Observer's shanten number (from calc_shanten_from_counts).
    pub shanten: i8,
    /// Round index (0-7: East 1 = 0, South 4 = 7).
    pub kyoku_index: u8,
    /// Honba (repeat) counter.
    pub honba: u8,
    /// Number of riichi sticks deposited on the table.
    pub kyotaku: u8,
}

// ---------------------------------------------------------------------------
// Encoding: game metadata (channels 43-61)
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode game metadata into channels 43-61.
    ///
    /// Layout:
    /// - Ch 43-46: riichi flags (4 players)
    /// - Ch 47-50: scores / 100000.0 (4 players)
    /// - Ch 51-54: relative score gaps (my - their) / 30000.0 (4 players)
    /// - Ch 55-58: shanten one-hot (0=tenpai, 1, 2, 3+)
    /// - Ch 59: round number (kyoku_index / 8.0)
    /// - Ch 60: honba / 10.0
    /// - Ch 61: kyotaku / 10.0
    #[inline]
    pub fn encode_metadata(&mut self, meta: &GameMetadata) {
        // Riichi flags (ch 43-46)
        for (i, &r) in meta.riichi.iter().enumerate() {
            if r {
                self.fill_channel(CH_META + i, 1.0);
            }
        }

        // Scores normalized (ch 47-50)
        for (i, &score) in meta.scores.iter().enumerate() {
            self.fill_channel(CH_META + 4 + i, score as f32 / 100_000.0);
        }

        // Relative score gaps (ch 51-54): (my_score - their_score) / 30000
        let my_score = meta.scores[0];
        for (i, &their_score) in meta.scores.iter().enumerate() {
            let gap = (my_score - their_score) as f32 / 30_000.0;
            self.fill_channel(CH_META + 8 + i, gap);
        }

        // Shanten one-hot (ch 55-58): 0=tenpai, 1, 2, 3+
        let sh = meta.shanten.clamp(0, 3) as usize;
        self.fill_channel(CH_META + 12 + sh, 1.0);

        // Round number (ch 59)
        self.fill_channel(CH_META + 16, meta.kyoku_index as f32 / 8.0);

        // Honba (ch 60)
        self.fill_channel(CH_META + 17, meta.honba as f32 / 10.0);

        // Kyotaku (ch 61)
        self.fill_channel(CH_META + 18, meta.kyotaku as f32 / 10.0);
    }
}

// ---------------------------------------------------------------------------
// Encoding: safety channels (62-84)
// ---------------------------------------------------------------------------

/// Number of opponents for safety channels.
const NUM_OPPS: usize = crate::safety::NUM_OPPONENTS; // 3

/// Iterate over set bits in a `u64` bitmask using trailing-zeros extraction.
///
/// More efficient than scanning all 34 positions when the mask is sparse
/// (typically 5-10 bits set).
#[inline]
fn for_each_set_bit(mut bits: u64, mut f: impl FnMut(usize)) {
    while bits != 0 {
        let idx = bits.trailing_zeros() as usize;
        f(idx);
        bits &= bits - 1; // clear lowest set bit
    }
}

impl ObservationEncoder {
    /// Encode safety info into channels 62-84 (23 channels total).
    ///
    /// Layout:
    /// - Ch 62-64: genbutsu_all (per opponent)
    /// - Ch 65-67: genbutsu_tedashi (per opponent)
    /// - Ch 68-70: genbutsu_riichi_era (per opponent)
    /// - Ch 71-73: suji (per opponent, float 0.0-1.0)
    /// - Ch 74-76: half-suji indicator (per opponent)
    /// - Ch 77-79: matagi-suji danger (per opponent)
    /// - Ch 80: kabe
    /// - Ch 81: one-chance
    /// - Ch 82-84: tenpai hints (riichi or cached tenpai prediction > 0.5)
    #[inline]
    pub fn encode_safety(&mut self, safety: &SafetyInfo) {
        for opp in 0..NUM_OPPS {
            for_each_set_bit(safety.genbutsu_all[opp], |tile| {
                self.set(CH_SAFETY + opp, tile, 1.0);
            });
            for_each_set_bit(safety.genbutsu_tedashi[opp], |tile| {
                self.set(CH_SAFETY + NUM_OPPS + opp, tile, 1.0);
            });
            for_each_set_bit(safety.genbutsu_riichi_era[opp], |tile| {
                self.set(CH_SAFETY + 2 * NUM_OPPS + opp, tile, 1.0);
            });
            for tile in 0..NUM_TILES {
                let suji = safety.suji[opp][tile];
                if suji > 0.0 {
                    self.set(CH_SAFETY + 3 * NUM_OPPS + opp, tile, suji);
                }
            }
        }

        // Ch 74-76: half-suji indicator per opponent
        for opp in 0..NUM_OPPS {
            for_each_set_bit(safety.half_suji[opp], |tile| {
                self.set(CH_SAFETY + 12 + opp, tile, 1.0);
            });
        }

        // Ch 77-79: matagi-suji danger per opponent
        for opp in 0..NUM_OPPS {
            for tile in 0..NUM_TILES {
                let m = safety.matagi[opp][tile];
                if m != 0.0 {
                    self.set(CH_SAFETY + 15 + opp, tile, m);
                }
            }
        }

        for_each_set_bit(safety.kabe, |tile| {
            self.set(CH_SAFETY + 18, tile, 1.0);
        });
        for_each_set_bit(safety.one_chance, |tile| {
            self.set(CH_SAFETY + 19, tile, 1.0);
        });

        // Ch 82-84: tenpai hints per opponent.
        for opp in 0..NUM_OPPS {
            if safety.tenpai_hint_active(opp) {
                self.fill_channel(CH_SAFETY + 20 + opp, 1.0);
            }
        }
    }

    /// Encode fixed-shape Group C search/belief context planes.
    #[inline]
    pub fn encode_search_features(&mut self, features: &SearchFeaturePlanes) {
        self.clear_range(CH_SEARCH, CH_SEARCH + SEARCH_CONTEXT_CHANNELS);

        for (idx, plane) in features.belief_fields.iter().enumerate() {
            self.copy_channel(CH_SEARCH_BELIEF + idx, plane);
        }
        for (idx, &weight) in features.mixture_weights.iter().enumerate() {
            self.fill_channel(CH_SEARCH_MIXTURE_WEIGHT + idx, weight);
        }
        self.fill_channel(CH_SEARCH_MIXTURE_ENTROPY, features.mixture_entropy);
        self.fill_channel(CH_SEARCH_MIXTURE_ESS, features.mixture_ess);
        self.copy_channel(CH_SEARCH_DELTA_Q, &features.delta_q);
        for (idx, plane) in features.opponent_risk.iter().enumerate() {
            self.copy_channel(CH_SEARCH_RISK + idx, plane);
        }
        for (idx, &stress) in features.opponent_stress.iter().enumerate() {
            self.fill_channel(CH_SEARCH_STRESS + idx, stress);
        }
        if features.belief_features_present {
            self.fill_channel(CH_SEARCH_MASKS, 1.0);
        }
        if features.search_features_present {
            self.fill_channel(CH_SEARCH_MASKS + 1, 1.0);
        }
        if features.robust_features_present {
            self.fill_channel(CH_SEARCH_MASKS + 2, 1.0);
        }
        if features.context_features_present {
            self.fill_channel(CH_SEARCH_MASKS + 3, 1.0);
        }

        let _ = CH_SEARCH_RESERVED;
        let _ = SEARCH_RESERVED_CHANNELS;
    }

    /// Encode fixed-shape Group D Hand-EV context planes.
    #[inline]
    pub fn encode_hand_ev_features(&mut self, hand_ev: &HandEvFeatures) {
        self.clear_range(CH_HAND_EV, CH_HAND_EV + HAND_EV_CHANNELS);

        for discard in 0..NUM_TILES {
            for horizon in 0..3 {
                self.set(
                    CH_HAND_EV_TENPAI + horizon,
                    discard,
                    hand_ev.tenpai_prob[discard][horizon],
                );
                self.set(
                    CH_HAND_EV_WIN + horizon,
                    discard,
                    hand_ev.win_prob[discard][horizon],
                );
            }
            self.set(CH_HAND_EV_SCORE, discard, hand_ev.expected_score[discard]);
        }
        for draw_tile in 0..NUM_TILES {
            for discard in 0..NUM_TILES {
                self.set(
                    CH_HAND_EV_UKEIRE + draw_tile,
                    discard,
                    hand_ev.ukeire[discard][draw_tile],
                );
            }
        }
        self.fill_channel(CH_HAND_EV_MASK, 1.0);
    }

    /// Encode a complete observation plus optional Group C / Group D context.
    #[allow(clippy::too_many_arguments)]
    pub fn encode_with_context(
        &mut self,
        hand: &[u8; NUM_TILES],
        drawn_tile: Option<u8>,
        open_meld_counts: &[u8; NUM_TILES],
        discards: &[PlayerDiscards; NUM_PLAYERS],
        melds: &[PlayerMelds; NUM_PLAYERS],
        dora: &DoraInfo,
        meta: &GameMetadata,
        safety: &SafetyInfo,
        search_features: Option<&SearchFeaturePlanes>,
        hand_ev: Option<&HandEvFeatures>,
    ) -> &[f32; OBS_SIZE] {
        self.encode(
            hand,
            drawn_tile,
            open_meld_counts,
            discards,
            melds,
            dora,
            meta,
            safety,
        );
        if let Some(features) = search_features {
            self.encode_search_features(features);
        }
        if let Some(features) = hand_ev {
            self.encode_hand_ev_features(features);
        }
        self.as_slice()
    }
}

// ---------------------------------------------------------------------------
// Incremental encoding: selective channel updates
// ---------------------------------------------------------------------------

/// Dirty flags indicating which channel groups need re-encoding.
///
/// Use with [`ObservationEncoder::encode_incremental`] to avoid
/// recomputing the full observation tensor when only a few groups changed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(transparent)]
pub struct DirtyFlags(pub u16);

impl DirtyFlags {
    /// Closed hand channels (0-3) need re-encoding.
    pub const HAND: Self = Self(1 << 0); // Ch 0-3
    /// Open meld hand channels (4-7) need re-encoding.
    pub const OPEN_MELD: Self = Self(1 << 1); // Ch 4-7
    /// Drawn tile channel (8) needs re-encoding.
    pub const DRAWN: Self = Self(1 << 2); // Ch 8
    /// Shanten mask channels (9-10) need re-encoding.
    pub const SHANTEN: Self = Self(1 << 3); // Ch 9-10
    /// Discard channels (11-22) need re-encoding.
    pub const DISCARDS: Self = Self(1 << 4); // Ch 11-22
    /// Meld channels (23-34) need re-encoding.
    pub const MELDS: Self = Self(1 << 5); // Ch 23-34
    /// Dora channels (35-42) need re-encoding.
    pub const DORA: Self = Self(1 << 6); // Ch 35-42
    /// Game metadata channels (43-61) need re-encoding.
    pub const META: Self = Self(1 << 7); // Ch 43-61
    /// Safety channels (62-84) need re-encoding.
    pub const SAFETY: Self = Self(1 << 8); // Ch 62-84
    /// Search/belief Group C channels (85-149) need re-encoding.
    pub const SEARCH: Self = Self(1 << 9);
    /// Hand-EV Group D channels (150-191) need re-encoding.
    pub const HAND_EV: Self = Self(1 << 10);
    /// All channels need re-encoding.
    pub const ALL: Self = Self(0x7FF);

    /// After a draw: hand, drawn tile, shanten, metadata.
    pub const AFTER_DRAW: Self = Self(
        Self::HAND.0
            | Self::DRAWN.0
            | Self::SHANTEN.0
            | Self::META.0
            | Self::SEARCH.0
            | Self::HAND_EV.0,
    );
    /// After a discard: hand, drawn, shanten, discards, metadata, safety.
    pub const AFTER_DISCARD: Self = Self(
        Self::HAND.0
            | Self::DRAWN.0
            | Self::SHANTEN.0
            | Self::DISCARDS.0
            | Self::META.0
            | Self::SAFETY.0
            | Self::SEARCH.0
            | Self::HAND_EV.0,
    );
    /// After a call: hand, open melds, shanten, discards, melds, meta, safety.
    pub const AFTER_CALL: Self = Self(
        Self::HAND.0
            | Self::OPEN_MELD.0
            | Self::SHANTEN.0
            | Self::DISCARDS.0
            | Self::MELDS.0
            | Self::META.0
            | Self::SAFETY.0
            | Self::SEARCH.0
            | Self::HAND_EV.0,
    );
    /// New round: everything.
    pub const NEW_ROUND: Self = Self::ALL;

    #[inline]
    /// Check whether all flags in `other` are set in `self`.
    pub const fn contains(self, other: Self) -> bool {
        (self.0 & other.0) == other.0
    }
    #[inline]
    /// Return a new `DirtyFlags` with all bits from both `self` and `other`.
    pub const fn union(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

// ---------------------------------------------------------------------------
// Full encode entry point
// ---------------------------------------------------------------------------

impl ObservationEncoder {
    /// Encode a complete observation from explicit game state components.
    ///
    /// Clears the buffer, then calls each sub-encoder in order.
    /// Returns a reference to the filled observation buffer.
    #[allow(clippy::too_many_arguments)]
    pub fn encode(
        &mut self,
        hand: &[u8; NUM_TILES],
        drawn_tile: Option<u8>,
        open_meld_counts: &[u8; NUM_TILES],
        discards: &[PlayerDiscards; NUM_PLAYERS],
        melds: &[PlayerMelds; NUM_PLAYERS],
        dora: &DoraInfo,
        meta: &GameMetadata,
        safety: &SafetyInfo,
    ) -> &[f32; OBS_SIZE] {
        self.clear();
        self.encode_hand(hand);
        self.encode_open_meld_hand(open_meld_counts);
        self.encode_drawn_tile(drawn_tile);
        self.encode_shanten_masks(hand);
        self.encode_discards(discards);
        self.encode_melds(melds);
        self.encode_dora(dora);
        self.encode_aka(dora);
        self.encode_metadata(meta);
        self.encode_safety(safety);
        self.as_slice()
    }
}

impl ObservationEncoder {
    /// Incrementally re-encode only the channel groups marked dirty.
    ///
    /// Unlike [`encode`], this does NOT clear the entire buffer. It only
    /// clears and rewrites the specific channel ranges that changed.
    /// Use [`DirtyFlags`] presets (`AFTER_DRAW`, `AFTER_DISCARD`,
    /// `AFTER_CALL`) for common game events.
    ///
    /// For a new round or first encode, use `DirtyFlags::ALL` or [`encode`].
    #[allow(clippy::too_many_arguments)]
    pub fn encode_incremental(
        &mut self,
        dirty: DirtyFlags,
        hand: &[u8; NUM_TILES],
        drawn_tile: Option<u8>,
        open_meld_counts: &[u8; NUM_TILES],
        discards: &[PlayerDiscards; NUM_PLAYERS],
        melds: &[PlayerMelds; NUM_PLAYERS],
        dora: &DoraInfo,
        meta: &GameMetadata,
        safety: &SafetyInfo,
    ) -> &[f32; OBS_SIZE] {
        if dirty.contains(DirtyFlags::HAND) {
            self.clear_range(CH_HAND, CH_HAND + 4);
            self.encode_hand(hand);
        }
        if dirty.contains(DirtyFlags::OPEN_MELD) {
            self.clear_range(CH_OPEN_MELD, CH_OPEN_MELD + 4);
            self.encode_open_meld_hand(open_meld_counts);
        }
        if dirty.contains(DirtyFlags::DRAWN) {
            self.clear_range(CH_DRAWN, CH_DRAWN + 1);
            self.encode_drawn_tile(drawn_tile);
        }
        if dirty.contains(DirtyFlags::SHANTEN) {
            self.clear_range(CH_SHANTEN_MASK, CH_SHANTEN_MASK + 2);
            self.encode_shanten_masks(hand);
        }
        if dirty.contains(DirtyFlags::DISCARDS) {
            self.clear_range(CH_DISCARDS, CH_DISCARDS + 12);
            self.encode_discards(discards);
        }
        if dirty.contains(DirtyFlags::MELDS) {
            self.clear_range(CH_MELDS, CH_MELDS + 12);
            self.encode_melds(melds);
        }
        if dirty.contains(DirtyFlags::DORA) {
            self.clear_range(CH_DORA, CH_AKA + 3);
            self.encode_dora(dora);
            self.encode_aka(dora);
        }
        if dirty.contains(DirtyFlags::META) {
            self.clear_range(CH_META, CH_META + 19);
            self.encode_metadata(meta);
        }
        if dirty.contains(DirtyFlags::SAFETY) {
            self.clear_range(CH_SAFETY, CH_SAFETY + 23);
            self.encode_safety(safety);
        }
        self.as_slice()
    }

    /// Incrementally re-encode baseline plus optional Group C / Group D context.
    #[allow(clippy::too_many_arguments)]
    pub fn encode_incremental_with_context(
        &mut self,
        dirty: DirtyFlags,
        hand: &[u8; NUM_TILES],
        drawn_tile: Option<u8>,
        open_meld_counts: &[u8; NUM_TILES],
        discards: &[PlayerDiscards; NUM_PLAYERS],
        melds: &[PlayerMelds; NUM_PLAYERS],
        dora: &DoraInfo,
        meta: &GameMetadata,
        safety: &SafetyInfo,
        search_features: Option<&SearchFeaturePlanes>,
        hand_ev: Option<&HandEvFeatures>,
    ) -> &[f32; OBS_SIZE] {
        self.encode_incremental(
            dirty,
            hand,
            drawn_tile,
            open_meld_counts,
            discards,
            melds,
            dora,
            meta,
            safety,
        );
        if dirty.contains(DirtyFlags::SEARCH) {
            self.clear_range(CH_SEARCH, CH_SEARCH + SEARCH_CONTEXT_CHANNELS);
            if let Some(features) = search_features {
                self.encode_search_features(features);
            }
        }
        if dirty.contains(DirtyFlags::HAND_EV) {
            self.clear_range(CH_HAND_EV, CH_HAND_EV + HAND_EV_CHANNELS);
            if let Some(features) = hand_ev {
                self.encode_hand_ev_features(features);
            }
        }
        self.as_slice()
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::safety::bit_set;

    /// Helper: read a single cell from the obs buffer.
    fn get(enc: &ObservationEncoder, ch: usize, tile: usize) -> f32 {
        enc.as_slice()[ch * NUM_TILES + tile]
    }

    #[test]
    fn new_encoder_is_zeroed() {
        let enc = ObservationEncoder::new();
        assert!(enc.as_slice().iter().all(|&v| v == 0.0));
    }

    #[test]
    fn clear_resets_buffer() {
        let mut enc = ObservationEncoder::new();
        enc.buffer[0] = 42.0;
        enc.buffer[OBS_SIZE - 1] = 99.0;
        enc.clear();
        assert!(enc.as_slice().iter().all(|&v| v == 0.0));
    }

    // -- Hand tests (ch 0-3) --

    #[test]
    fn hand_single_tile() {
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[0] = 1;
        enc.encode_hand(&hand);
        assert_eq!(get(&enc, 0, 0), 1.0);
        assert_eq!(get(&enc, 1, 0), 0.0);
    }

    #[test]
    fn hand_four_copies() {
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[5] = 4;
        enc.encode_hand(&hand);
        assert_eq!(get(&enc, 0, 5), 1.0);
        assert_eq!(get(&enc, 1, 5), 1.0);
        assert_eq!(get(&enc, 2, 5), 1.0);
        assert_eq!(get(&enc, 3, 5), 1.0);
    }

    #[test]
    fn hand_three_copies_not_four() {
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[10] = 3;
        enc.encode_hand(&hand);
        assert_eq!(get(&enc, 2, 10), 1.0);
        assert_eq!(get(&enc, 3, 10), 0.0);
    }

    // -- Open meld hand tests (ch 4-7) --

    #[test]
    fn open_meld_hand_thermometer() {
        let mut enc = ObservationEncoder::new();
        let mut counts = [0u8; NUM_TILES];
        counts[0] = 3; // 3 tiles of type 0 from melds
        counts[9] = 1; // 1 tile of type 9
        enc.encode_open_meld_hand(&counts);
        // tile 0: ch4=1, ch5=1, ch6=1, ch7=0
        assert_eq!(get(&enc, 4, 0), 1.0);
        assert_eq!(get(&enc, 5, 0), 1.0);
        assert_eq!(get(&enc, 6, 0), 1.0);
        assert_eq!(get(&enc, 7, 0), 0.0);
        // tile 9: ch4=1, ch5=0
        assert_eq!(get(&enc, 4, 9), 1.0);
        assert_eq!(get(&enc, 5, 9), 0.0);
    }

    #[test]
    fn open_meld_hand_four() {
        let mut enc = ObservationEncoder::new();
        let mut counts = [0u8; NUM_TILES];
        counts[27] = 4; // kan of East
        enc.encode_open_meld_hand(&counts);
        assert_eq!(get(&enc, 7, 27), 1.0);
    }

    // -- Drawn tile tests (ch 8) --

    #[test]
    fn drawn_tile_encoded() {
        let mut enc = ObservationEncoder::new();
        enc.encode_drawn_tile(Some(5));
        assert_eq!(get(&enc, 8, 5), 1.0);
        assert_eq!(get(&enc, 8, 0), 0.0);
    }

    #[test]
    fn drawn_tile_none_leaves_channel_zero() {
        let mut enc = ObservationEncoder::new();
        enc.encode_drawn_tile(None);
        for t in 0..NUM_TILES {
            assert_eq!(get(&enc, 8, t), 0.0);
        }
    }

    // -- Shanten mask tests (ch 9-10) --

    #[test]
    fn shanten_masks_complete_hand() {
        // Complete 14-tile hand: 123m 456m 789m 123p 11s
        // 4 sequences + 1 pair = agari (shanten = -1)
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[..9].fill(1); // 1-9m
        hand[9] = 1;
        hand[10] = 1;
        hand[11] = 1; // 1-3p
        hand[18] = 2; // 1s pair
        // 14 tiles, len_div3=4, shanten=-1
        enc.encode_shanten_masks(&hand);
        // After discarding any tile, shanten goes from -1 to 0 (worsens).
        // So next-shanten (ch10) should have NO tiles set.
        for t in 0..NUM_TILES {
            assert_eq!(get(&enc, 10, t), 0.0);
        }
    }

    #[test]
    fn shanten_masks_one_away() {
        // Simple iishanten hand: 1m,2m,3m, 4m,5m,6m, 7m,8m,9m, 1p,1p,1p, 2p, drawn 5s
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[0] = 1;
        hand[1] = 1;
        hand[2] = 1; // 123m
        hand[3] = 1;
        hand[4] = 1;
        hand[5] = 1; // 456m
        hand[6] = 1;
        hand[7] = 1;
        hand[8] = 1; // 789m
        hand[9] = 3; // 1p x3
        hand[10] = 1; // 2p
        hand[22] = 1; // 5s (drawn tile)
        // 14 tiles. This is tenpai (waiting on 2p or 5s-related).
        // Actually 123m 456m 789m 111p + 2p 5s = tenpai waiting on 3p
        // shanten = 0 (tenpai)
        enc.encode_shanten_masks(&hand);
        // Discarding 2p or 5s keeps tenpai (shanten stays 0), so ch9 should be set
        // The exact tiles depend on shanten calc, but at minimum some tiles on ch9
        let ch9_sum: f32 = (0..NUM_TILES).map(|t| get(&enc, 9, t)).sum();
        assert!(
            ch9_sum > 0.0,
            "keep-shanten mask should have some tiles set"
        );
    }

    // -- Discard tests (ch 11-22) --

    fn empty_discards() -> [PlayerDiscards; NUM_PLAYERS] {
        [
            PlayerDiscards::new(),
            PlayerDiscards::new(),
            PlayerDiscards::new(),
            PlayerDiscards::new(),
        ]
    }

    #[test]
    fn discard_presence_and_tedashi() {
        let mut enc = ObservationEncoder::new();
        let mut discards = empty_discards();
        discards[0].push(DiscardEntry {
            tile: 5,
            is_tedashi: true,
            turn: 0,
        });
        discards[1].push(DiscardEntry {
            tile: 10,
            is_tedashi: false,
            turn: 0,
        });
        enc.encode_discards(&discards);
        // Player 0: ch_base=11, presence=ch11, tedashi=ch12
        assert_eq!(get(&enc, 11, 5), 1.0);
        assert_eq!(get(&enc, 12, 5), 1.0);
        // Player 1: ch_base=14, presence=ch14, tedashi=ch15
        assert_eq!(get(&enc, 14, 10), 1.0);
        assert_eq!(get(&enc, 15, 10), 0.0); // tsumogiri
    }

    #[test]
    fn discard_temporal_decay() {
        let mut enc = ObservationEncoder::new();
        let mut discards = empty_discards();
        discards[0].push(DiscardEntry {
            tile: 0,
            is_tedashi: false,
            turn: 0,
        });
        discards[0].push(DiscardEntry {
            tile: 1,
            is_tedashi: false,
            turn: 5,
        });
        enc.encode_discards(&discards);
        // temporal ch = 11 + 2 = 13
        assert!((get(&enc, 13, 1) - 1.0).abs() < 1e-6);
        let expected = (-1.0f32).exp();
        assert!((get(&enc, 13, 0) - expected).abs() < 1e-6);
    }

    // -- Meld tests (ch 23-34) --

    fn empty_melds() -> [PlayerMelds; NUM_PLAYERS] {
        [
            PlayerMelds::new(),
            PlayerMelds::new(),
            PlayerMelds::new(),
            PlayerMelds::new(),
        ]
    }

    #[test]
    fn meld_chi() {
        let mut enc = ObservationEncoder::new();
        let mut melds = empty_melds();
        melds[0].push(MeldInfo {
            tiles: [0, 1, 2, 0],
            tile_count: 3,
            meld_type: MeldType::Chi,
        });
        enc.encode_melds(&melds);
        // Player 0 chi = ch 23
        assert_eq!(get(&enc, 23, 0), 1.0);
        assert_eq!(get(&enc, 23, 1), 1.0);
        assert_eq!(get(&enc, 23, 2), 1.0);
        assert_eq!(get(&enc, 24, 0), 0.0); // pon channel empty
    }

    #[test]
    fn meld_pon() {
        let mut enc = ObservationEncoder::new();
        let mut melds = empty_melds();
        melds[2].push(MeldInfo {
            tiles: [27, 27, 27, 0],
            tile_count: 3,
            meld_type: MeldType::Pon,
        });
        enc.encode_melds(&melds);
        // Player 2: ch_base = 23 + 3*2 = 29, pon = ch 30
        assert_eq!(get(&enc, 30, 27), 1.0);
    }

    #[test]
    fn meld_kan() {
        let mut enc = ObservationEncoder::new();
        let mut melds = empty_melds();
        melds[1].push(MeldInfo {
            tiles: [31, 31, 31, 31],
            tile_count: 4,
            meld_type: MeldType::Kan,
        });
        enc.encode_melds(&melds);
        // Player 1: ch_base = 23 + 3*1 = 26, kan = ch 28
        assert_eq!(get(&enc, 28, 31), 1.0);
    }

    // -- Dora tests (ch 35-39) --

    #[test]
    fn dora_indicator_thermometer_single() {
        let mut enc = ObservationEncoder::new();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 1,
            aka_flags: [false; 3],
        };
        enc.encode_dora(&dora);
        assert_eq!(get(&enc, 35, 0), 1.0); // >= 1
        assert_eq!(get(&enc, 36, 0), 0.0); // >= 2 not set
    }

    #[test]
    fn dora_indicator_thermometer_multiple_same() {
        let mut enc = ObservationEncoder::new();
        let dora = DoraInfo {
            indicators: [5, 5, 5, 0, 0],
            indicator_count: 3,
            aka_flags: [false; 3],
        };
        enc.encode_dora(&dora);
        assert_eq!(get(&enc, 35, 5), 1.0); // >= 1
        assert_eq!(get(&enc, 36, 5), 1.0); // >= 2
        assert_eq!(get(&enc, 37, 5), 1.0); // >= 3
        assert_eq!(get(&enc, 38, 5), 0.0); // >= 4 not set
    }

    #[test]
    fn dora_indicator_thermometer_different() {
        let mut enc = ObservationEncoder::new();
        let dora = DoraInfo {
            indicators: [0, 10, 0, 0, 0],
            indicator_count: 2,
            aka_flags: [false; 3],
        };
        enc.encode_dora(&dora);
        assert_eq!(get(&enc, 35, 0), 1.0);
        assert_eq!(get(&enc, 35, 10), 1.0);
        assert_eq!(get(&enc, 36, 0), 0.0);
        assert_eq!(get(&enc, 36, 10), 0.0);
    }

    // -- Aka tests (ch 40-42) --

    #[test]
    fn aka_dora_plane_fill() {
        let mut enc = ObservationEncoder::new();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 0,
            aka_flags: [true, false, true],
        };
        enc.encode_aka(&dora);
        // Ch 40 (5m): entire channel filled
        assert_eq!(get(&enc, 40, 0), 1.0);
        assert_eq!(get(&enc, 40, 33), 1.0);
        // Ch 41 (5p): not set
        assert_eq!(get(&enc, 41, 0), 0.0);
        // Ch 42 (5s): entire channel filled
        assert_eq!(get(&enc, 42, 0), 1.0);
    }

    // -- Metadata tests (ch 43-61) --

    fn test_metadata() -> GameMetadata {
        GameMetadata {
            riichi: [true, false, false, false],
            scores: [25000, 25000, 25000, 25000],
            shanten: 1,
            kyoku_index: 0,
            honba: 2,
            kyotaku: 1,
        }
    }

    #[test]
    fn metadata_riichi_and_scores() {
        let mut enc = ObservationEncoder::new();
        enc.encode_metadata(&test_metadata());
        // Self riichi = ch 43 filled
        assert_eq!(get(&enc, 43, 0), 1.0);
        // Opponent 1 riichi = ch 44 -- NOT set
        assert_eq!(get(&enc, 44, 0), 0.0);
        // Score ch 47 = 25000/100000 = 0.25
        assert!((get(&enc, 47, 0) - 0.25).abs() < 1e-6);
    }

    #[test]
    fn metadata_score_gaps() {
        let mut enc = ObservationEncoder::new();
        let mut meta = test_metadata();
        meta.scores = [30000, 25000, 20000, 25000];
        enc.encode_metadata(&meta);
        // gap[0] = (30000-30000)/30000 = 0.0
        assert!((get(&enc, 51, 0) - 0.0).abs() < 1e-6);
        // gap[1] = (30000-25000)/30000 = 0.1667
        assert!((get(&enc, 52, 0) - 5000.0 / 30000.0).abs() < 1e-4);
        // gap[2] = (30000-20000)/30000 = 0.3333
        assert!((get(&enc, 53, 0) - 10000.0 / 30000.0).abs() < 1e-4);
    }

    #[test]
    fn metadata_shanten_one_hot() {
        // shanten = 0 (tenpai) -> ch 55
        let mut enc = ObservationEncoder::new();
        let mut meta = test_metadata();
        meta.shanten = 0;
        enc.encode_metadata(&meta);
        assert_eq!(get(&enc, 55, 0), 1.0);
        assert_eq!(get(&enc, 56, 0), 0.0);

        // shanten = 2 -> ch 57
        enc.clear();
        meta.shanten = 2;
        enc.encode_metadata(&meta);
        assert_eq!(get(&enc, 57, 0), 1.0);
        assert_eq!(get(&enc, 55, 0), 0.0);

        // shanten = 5 (clamped to 3+) -> ch 58
        enc.clear();
        meta.shanten = 5;
        enc.encode_metadata(&meta);
        assert_eq!(get(&enc, 58, 0), 1.0);
    }

    #[test]
    fn metadata_round_honba_kyotaku() {
        let mut enc = ObservationEncoder::new();
        let mut meta = test_metadata();
        meta.kyoku_index = 4; // South 1
        meta.honba = 3;
        meta.kyotaku = 2;
        enc.encode_metadata(&meta);
        // Ch 59: 4/8 = 0.5
        assert!((get(&enc, 59, 0) - 0.5).abs() < 1e-6);
        // Ch 60: 3/10 = 0.3
        assert!((get(&enc, 60, 0) - 0.3).abs() < 1e-6);
        // Ch 61: 2/10 = 0.2
        assert!((get(&enc, 61, 0) - 0.2).abs() < 1e-6);
    }

    // -- Safety tests (ch 62-84, unchanged) --

    #[test]
    fn safety_genbutsu_channels() {
        let mut enc = ObservationEncoder::new();
        let mut si = SafetyInfo::new();
        bit_set(&mut si.genbutsu_all[0], 5);
        bit_set(&mut si.genbutsu_tedashi[1], 10);
        bit_set(&mut si.genbutsu_riichi_era[2], 20);
        enc.encode_safety(&si);
        assert_eq!(get(&enc, 62, 5), 1.0);
        assert_eq!(get(&enc, 66, 10), 1.0);
        assert_eq!(get(&enc, 70, 20), 1.0);
    }

    #[test]
    fn safety_suji_channel() {
        let mut enc = ObservationEncoder::new();
        let mut si = SafetyInfo::new();
        si.suji[0][0] = 1.0;
        enc.encode_safety(&si);
        assert_eq!(get(&enc, 71, 0), 1.0);
    }

    #[test]
    fn safety_kabe_and_one_chance() {
        let mut enc = ObservationEncoder::new();
        let mut si = SafetyInfo::new();
        bit_set(&mut si.kabe, 15);
        bit_set(&mut si.one_chance, 20);
        enc.encode_safety(&si);
        assert_eq!(get(&enc, 80, 15), 1.0);
        assert_eq!(get(&enc, 81, 20), 1.0);
    }

    #[test]
    fn safety_tenpai_hint_uses_cached_prediction_threshold() {
        let mut enc = ObservationEncoder::new();
        let mut si = SafetyInfo::new();
        si.set_tenpai_prediction(1, 0.75);
        si.set_tenpai_prediction(2, 0.5);
        enc.encode_safety(&si);
        assert_eq!(get(&enc, 83, 0), 1.0);
        assert_eq!(get(&enc, 84, 0), 0.0);
    }

    #[test]
    fn safety_tenpai_hint_always_respects_riichi_status() {
        let mut enc = ObservationEncoder::new();
        let mut si = SafetyInfo::new();
        si.on_riichi(0);
        si.set_tenpai_prediction(0, 0.1);
        enc.encode_safety(&si);
        assert_eq!(get(&enc, 82, 0), 1.0);
    }

    #[test]
    fn baseline_encode_zero_fills_dynamic_groups() {
        let mut enc = ObservationEncoder::new();
        let hand = [0u8; NUM_TILES];
        let open_meld = [0u8; NUM_TILES];
        let discards = empty_discards();
        let melds = empty_melds();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 0,
            aka_flags: [false; 3],
        };
        let meta = test_metadata();
        let safety = SafetyInfo::new();
        enc.encode(
            &hand, None, &open_meld, &discards, &melds, &dora, &meta, &safety,
        );
        assert!(
            enc.as_slice()[CH_SEARCH * NUM_TILES..]
                .iter()
                .all(|&v| v == 0.0)
        );
    }

    #[test]
    fn search_features_fill_presence_masks_and_planes() {
        let mut enc = ObservationEncoder::new();
        let mut search = SearchFeaturePlanes {
            belief_features_present: true,
            search_features_present: true,
            robust_features_present: true,
            context_features_present: true,
            ..SearchFeaturePlanes::default()
        };
        search.belief_fields[0][5] = 0.75;
        search.mixture_weights[1] = 0.4;
        search.mixture_entropy = 0.8;
        search.mixture_ess = 2.5;
        search.delta_q[7] = -0.2;
        search.opponent_risk[2][9] = 0.6;
        search.opponent_stress[1] = 0.3;
        enc.encode_search_features(&search);
        assert!((get(&enc, CH_SEARCH_BELIEF, 5) - 0.75).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_MIXTURE_WEIGHT + 1, 0) - 0.4).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_MIXTURE_ENTROPY, 0) - 0.8).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_MIXTURE_ESS, 0) - 2.5).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_DELTA_Q, 7) + 0.2).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_RISK + 2, 9) - 0.6).abs() < 1e-6);
        assert!((get(&enc, CH_SEARCH_STRESS + 1, 0) - 0.3).abs() < 1e-6);
        assert_eq!(get(&enc, CH_SEARCH_MASKS, 0), 1.0);
        assert_eq!(get(&enc, CH_SEARCH_MASKS + 1, 0), 1.0);
        assert_eq!(get(&enc, CH_SEARCH_MASKS + 2, 0), 1.0);
        assert_eq!(get(&enc, CH_SEARCH_MASKS + 3, 0), 1.0);
    }

    #[test]
    fn hand_ev_features_fill_expected_planes() {
        let mut enc = ObservationEncoder::new();
        let mut hand_ev = HandEvFeatures::default();
        hand_ev.tenpai_prob[3][0] = 0.2;
        hand_ev.win_prob[3][2] = 0.5;
        hand_ev.expected_score[3] = 6400.0;
        hand_ev.ukeire[3][6] = 2.0;
        enc.encode_hand_ev_features(&hand_ev);
        assert!((get(&enc, CH_HAND_EV_TENPAI, 3) - 0.2).abs() < 1e-6);
        assert!((get(&enc, CH_HAND_EV_WIN + 2, 3) - 0.5).abs() < 1e-6);
        assert!((get(&enc, CH_HAND_EV_SCORE, 3) - 6400.0).abs() < 1e-6);
        assert!((get(&enc, CH_HAND_EV_UKEIRE + 6, 3) - 2.0).abs() < 1e-6);
        assert_eq!(get(&enc, CH_HAND_EV_MASK, 0), 1.0);
    }

    // -- Full encode test --

    #[test]
    fn full_encode_returns_correct_size() {
        let mut enc = ObservationEncoder::new();
        let hand = [0u8; NUM_TILES];
        let open_meld = [0u8; NUM_TILES];
        let discards = empty_discards();
        let melds = empty_melds();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 0,
            aka_flags: [false; 3],
        };
        let meta = test_metadata();
        let safety = SafetyInfo::new();
        let obs = enc.encode(
            &hand, None, &open_meld, &discards, &melds, &dora, &meta, &safety,
        );
        assert_eq!(obs.len(), OBS_SIZE);
    }

    #[test]
    fn full_encode_clears_between_calls() {
        let mut enc = ObservationEncoder::new();
        let mut hand = [0u8; NUM_TILES];
        hand[0] = 3;
        let open_meld = [0u8; NUM_TILES];
        let discards = empty_discards();
        let melds = empty_melds();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 0,
            aka_flags: [false; 3],
        };
        let meta = test_metadata();
        let safety = SafetyInfo::new();
        enc.encode(
            &hand, None, &open_meld, &discards, &melds, &dora, &meta, &safety,
        );
        assert_eq!(get(&enc, 2, 0), 1.0);

        let empty_hand = [0u8; NUM_TILES];
        enc.encode(
            &empty_hand,
            None,
            &open_meld,
            &discards,
            &melds,
            &dora,
            &meta,
            &safety,
        );
        assert_eq!(get(&enc, 2, 0), 0.0);
    }

    #[test]
    fn incremental_matches_full_encode() {
        let mut hand = [0u8; NUM_TILES];
        hand[0] = 3;
        hand[9] = 2;
        hand[18] = 1;
        let open_meld = [0u8; NUM_TILES];
        let discards = empty_discards();
        let melds = empty_melds();
        let dora = DoraInfo {
            indicators: [4, 0, 0, 0, 0],
            indicator_count: 1,
            aka_flags: [true, false, false],
        };
        let meta = test_metadata();
        let safety = SafetyInfo::new();

        // Full encode
        let mut full = ObservationEncoder::new();
        full.encode(
            &hand,
            Some(18),
            &open_meld,
            &discards,
            &melds,
            &dora,
            &meta,
            &safety,
        );

        // Incremental with ALL flags = same as full encode
        let mut inc = ObservationEncoder::new();
        inc.encode_incremental(
            DirtyFlags::ALL,
            &hand,
            Some(18),
            &open_meld,
            &discards,
            &melds,
            &dora,
            &meta,
            &safety,
        );

        for i in 0..OBS_SIZE {
            assert!(
                (full.as_slice()[i] - inc.as_slice()[i]).abs() < 1e-6,
                "mismatch at index {}: full={}, inc={}",
                i,
                full.as_slice()[i],
                inc.as_slice()[i],
            );
        }
    }

    #[test]
    fn incremental_partial_updates_only_dirty() {
        let hand = [0u8; NUM_TILES];
        let open_meld = [0u8; NUM_TILES];
        let discards = empty_discards();
        let melds = empty_melds();
        let dora = DoraInfo {
            indicators: [0, 0, 0, 0, 0],
            indicator_count: 0,
            aka_flags: [false; 3],
        };
        let meta = test_metadata();
        let safety = SafetyInfo::new();

        let mut enc = ObservationEncoder::new();
        // Full encode first to set baseline
        enc.encode(
            &hand, None, &open_meld, &discards, &melds, &dora, &meta, &safety,
        );
        let baseline = *enc.as_slice();

        // Incremental with only META dirty -- only ch 43-61 should change
        let mut meta2 = test_metadata();
        meta2.scores = [50000, 10000, 10000, 30000];
        enc.encode_incremental(
            DirtyFlags::META,
            &hand,
            None,
            &open_meld,
            &discards,
            &melds,
            &dora,
            &meta2,
            &safety,
        );

        // Ch 0-42 should be unchanged
        for (i, &base_val) in baseline[..(CH_META * NUM_TILES)].iter().enumerate() {
            assert_eq!(enc.as_slice()[i], base_val, "non-meta ch changed at {i}");
        }
        // Ch 43-61 should differ (scores changed)
        let meta_start = CH_META * NUM_TILES;
        let scores_start = meta_start + 4 * NUM_TILES; // ch 47
        assert!((enc.as_slice()[scores_start] - 0.5).abs() < 1e-6); // 50000/100000
    }
}
